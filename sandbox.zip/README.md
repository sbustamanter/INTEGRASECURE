# Universal Template

This template is based on a forked version of the [Universal image](https://github.com/codesandbox/devcontainer-images/pkgs/container/devcontainers%2Funiversal) from the Devcontainers team.

It contains almost all languages. It's the perfect starter for projects that can go in any direction.
